
import "./globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Holistic Health Quest — Sleep Toolkit",
  description: "Patient Sleep Toolkit by The Healthcare Navigator",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
