
import Link from "next/link";

export default function Home() {
  return (
    <main className="min-h-screen flex items-center justify-center p-6">
      <div className="max-w-2xl text-center">
        <h1 className="text-3xl font-bold text-emerald-700">Holistic Health Quest</h1>
        <p className="text-muted-foreground mt-2">by The Healthcare Navigator</p>
        <p className="mt-6">Open the interactive patient tool:</p>
        <Link href="/sleep-toolkit" className="btn btn-solid mt-4">Open Sleep Toolkit</Link>
      </div>
    </main>
  );
}
