'use client';
import React, { useEffect, useMemo, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { Download, Plus, Trash2, RefreshCcw, Printer, FileText } from "lucide-react";

const BRAND = {
  name: "Holistic Health Quest",
  subtitle: "by The Healthcare Navigator",
  primaryClass: "text-emerald-600",
  accentClass: "bg-emerald-600",
  logoUrl: "https://healthcarenavigator.co/favicon.ico",
  siteUrl: "https://healthcarenavigator.co",
};

interface ChecklistItem { id: string; label: string; done: boolean; help?: string; }
interface DayChecklist {
  date: string;
  morning: ChecklistItem[]; midday: ChecklistItem[]; evening: ChecklistItem[]; airway: ChecklistItem[]; supplements: ChecklistItem[];
}
interface MetricEntry {
  id: string; date: string; bedtime: string; waketime: string;
  sleepLatencyMin?: number; awakenings?: number; returnToSleepMin?: number; totalSleepHours?: number; sleepEfficiencyPct?: number;
  bloatScore?: number; energyScore?: number; notes?: string;
}
interface DataModel {
  checklists: Record<string, DayChecklist>;
  metrics: MetricEntry[];
  settings: { defaultBedtime: string; defaultWaketime: string; showHistamineTips: boolean; brandAccent?: string; logoUrl?: string; };
}

const STORAGE_KEY = "tw_sleep_toolkit_v3";

const todayISO = () => new Date().toISOString().slice(0,10);
const defaultChecklist = (date: string): DayChecklist => ({
  date,
  morning: [
    { id: "light", label: "10–15 min outdoor morning light", done: false, help: "Get outside within 10–20 min of waking." },
    { id: "hydrate", label: "Hydrate 12–20 oz water", done: false },
    { id: "protein", label: "Protein-forward breakfast (20–40 g)", done: false },
    { id: "move5", label: "5–10 min mobility/walk", done: false },
    { id: "caffeine", label: "If caffeine, finish before 10:30 am", done: false },
  ],
  midday: [
    { id: "daylight_breaks", label: "2–3 daylight breaks (5 min)", done: false },
    { id: "nap_rule", label: "No naps after 2 pm / ≤ 20 min", done: false },
    { id: "train", label: "Training done ≥6 h before bed (if HIIT)", done: false },
  ],
  evening: [
    { id: "dinner_time", label: "Finish big meal ≥3 h before bed", done: false },
    { id: "pm_snack", label: "Optional protein+starch snack 60–90 min pre‑bed", done: false },
    { id: "screens", label: "Screens off last 60 min or audio-only", done: false },
    { id: "lights", label: "Dim warm lighting 90 min pre‑bed", done: false },
    { id: "hot_shower", label: "Hot shower 1 h pre‑bed or warm foot soak", done: false },
    { id: "wind_down", label: "20–30 min wind‑down: NSDR / stretch / journal", done: false },
    { id: "room", label: "Bedroom cool, dark, quiet; HEPA on", done: false },
  ],
  airway: [
    { id: "saline_pm", label: "Nasal saline rinse (after work + pre‑bed)", done: false },
    { id: "shower", label: "Shower/wash off dust/pollen", done: false },
    { id: "oral", label: "Brush + floss; xylitol gum after meals", done: false },
  ],
  supplements: [
    { id: "mg_gly", label: "Magnesium glycinate 200–300 mg with dinner", done: false },
    { id: "glycine", label: "Glycine 3 g at bedtime (optional)", done: false },
    { id: "theanine", label: "L‑theanine 100–200 mg pre‑bed (if using)", done: false },
    { id: "melatonin", label: "Melatonin 0.3–1 mg 60–90 min pre‑bed (only if needed)", done: false },
    { id: "vitc", label: "Vitamin C 250–500 mg with dinner (optional)", done: false },
    { id: "quercetin", label: "Quercetin 250–500 mg with dinner (optional)", done: false },
  ],
});
const pct = (n:number, d:number)=> d>0? Math.round(100*n/d):0;
const toCSV = (metrics: MetricEntry[]) => {
  const header = ["date","bedtime","waketime","sleepLatencyMin","awakenings","returnToSleepMin","totalSleepHours","sleepEfficiencyPct","bloatScore","energyScore","notes"].join(",");
  const rows = metrics.map(m=> [m.date,m.bedtime||"",m.waketime||"",m.sleepLatencyMin??"",m.awakenings??"",m.returnToSleepMin??"",m.totalSleepHours??"",m.sleepEfficiencyPct??"",m.bloatScore??"",m.energyScore??"", (m.notes||"").replaceAll(/\n|\r/g," ")].join(","));
  return [header, ...rows].join("\n");
};
function useLocalData(): [DataModel, React.Dispatch<React.SetStateAction<DataModel>>] {
  const [data, setData] = useState<DataModel>(()=>{
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) { try { return JSON.parse(raw); } catch {} }
    const d = todayISO();
    return { checklists: { [d]: defaultChecklist(d) }, metrics: [], settings: { defaultBedtime: "22:30", defaultWaketime: "06:30", showHistamineTips: true, brandAccent: BRAND.accentClass, logoUrl: BRAND.logoUrl } };
  });
  useEffect(()=>{ localStorage.setItem(STORAGE_KEY, JSON.stringify(data)); }, [data]);
  return [data, setData];
}

const SectionTitle: React.FC<{title:string; right?:React.ReactNode}> = ({title, right}) => (
  <div className="flex items-center justify-between mb-2">
    <h3 className="text-lg font-semibold">{title}</h3>
    {right}
  </div>
);

const ChecklistBlock: React.FC<{ title: string; items: ChecklistItem[]; onToggle:(id:string,v:boolean)=>void; onReset:()=>void; }> = ({title,items,onToggle,onReset}) => {
  const completed = items.filter(i=>i.done).length;
  const progress = pct(completed, items.length);
  return (
    <Card className="mb-4 print:break-inside-avoid">
      <CardHeader className="pb-2">
        <SectionTitle title={title} right={<div className="flex items-center gap-2"><Progress value={progress} className="w-32" /><span className="text-xs text-muted-foreground">{progress}%</span><Button onClick={onReset} className="btn-outline no-print"><RefreshCcw className="h-4 w-4 mr-1"/>Reset</Button></div>} />
      </CardHeader>
      <CardContent className="grid gap-3">
        {items.map(it => (
          <label key={it.id} className="flex items-start gap-3 text-sm">
            <Checkbox checked={it.done} onCheckedChange={(v)=> onToggle(it.id, Boolean(v))} />
            <div>
              <div className="font-medium">{it.label}</div>
              {it.help && <div className="text-xs text-muted-foreground">{it.help}</div>}
            </div>
          </label>
        ))}
      </CardContent>
    </Card>
  );
};

const MetricsForm: React.FC<{ entry?:MetricEntry; onSave:(e:MetricEntry)=>void; defaults:{bedtime:string; waketime:string;} }> = ({entry,onSave,defaults}) => {
  const [state, setState] = useState<MetricEntry>(entry || { id: crypto.randomUUID(), date: todayISO(), bedtime: defaults.bedtime, waketime: defaults.waketime, notes: "" });
  useEffect(()=>{ if(entry) setState(entry); },[entry]);
  const set = (k: keyof MetricEntry, v:any)=> setState(s=> ({...s, [k]: v}));
  const calcEfficiency = () => {
    try {
      const [bh,bm] = state.bedtime.split(":").map(Number);
      const [wh,wm] = state.waketime.split(":").map(Number);
      let minutesInBed = (wh*60+wm) - (bh*60+bm);
      if (minutesInBed <= 0) minutesInBed += 24*60;
      const sleepMin = Math.max(0, (state.totalSleepHours ?? 0) * 60);
      const eff = Math.round((sleepMin / minutesInBed) * 100);
      return isFinite(eff) && eff>=0 ? eff : undefined;
    } catch { return undefined; }
  };
  useEffect(()=>{ setState(s=> ({...s, sleepEfficiencyPct: calcEfficiency()})); }, [state.bedtime, state.waketime, state.totalSleepHours]);

  return (
    <Card className="mb-4 print:break-inside-avoid">
      <CardHeader className="pb-2"><CardTitle className="text-base">Daily Sleep & Symptom Log</CardTitle></CardHeader>
      <CardContent className="grid md:grid-cols-3 gap-4">
        <div><Label className="label">Date</Label><Input type="date" value={state.date} onChange={e=> set("date", e.target.value)} /></div>
        <div><Label className="label">Bedtime</Label><Input type="time" value={state.bedtime} onChange={e=> set("bedtime", e.target.value)} /></div>
        <div><Label className="label">Wake time</Label><Input type="time" value={state.waketime} onChange={e=> set("waketime", e.target.value)} /></div>
        <div><Label className="label">Minutes to fall asleep</Label><Input type="number" min={0} value={state.sleepLatencyMin ?? ""} onChange={e=> set("sleepLatencyMin", e.target.value===""? undefined : Number(e.target.value))} /></div>
        <div><Label className="label">Night awakenings</Label><Input type="number" min={0} value={state.awakenings ?? ""} onChange={e=> set("awakenings", e.target.value===""? undefined : Number(e.target.value))} /></div>
        <div><Label className="label">Avg minutes to return to sleep</Label><Input type="number" min={0} value={state.returnToSleepMin ?? ""} onChange={e=> set("returnToSleepMin", e.target.value===""? undefined : Number(e.target.value))} /></div>
        <div><Label className="label">Total sleep (hours)</Label><Input type="number" step={0.1} min={0} value={state.totalSleepHours ?? ""} onChange={e=> set("totalSleepHours", e.target.value===""? undefined : Number(e.target.value))} /></div>
        <div><Label className="label">Sleep efficiency (%)</Label><Input value={state.sleepEfficiencyPct ?? ""} readOnly /></div>
        <div><Label className="label">Bloat (0–10)</Label><Input type="number" min={0} max={10} value={state.bloatScore ?? ""} onChange={e=> set("bloatScore", e.target.value===""? undefined : Number(e.target.value))} /></div>
        <div><Label className="label">Morning energy (1–10)</Label><Input type="number" min={1} max={10} value={state.energyScore ?? ""} onChange={e=> set("energyScore", e.target.value===""? undefined : Number(e.target.value))} /></div>
        <div className="md:col-span-3"><Label className="label">Notes</Label><Textarea value={state.notes || ""} onChange={e=> set("notes", e.target.value)} placeholder="Late meal? Extra dust exposure? Supplements taken?" /></div>
        <div className="md:col-span-3 flex gap-2 no-print"><Button onClick={()=> onSave(state)} className="btn-outline flex items-center gap-2"><Plus className="h-4 w-4" />Save Entry</Button></div>
      </CardContent>
    </Card>
  );
};

const EntriesTable: React.FC<{ entries: MetricEntry[]; onDelete:(id:string)=>void; }> = ({entries,onDelete}) => (
  <Card className="print:break-inside-avoid">
    <CardHeader className="pb-2"><CardTitle className="text-base">Log History</CardTitle></CardHeader>
    <CardContent className="overflow-x-auto">
      <table className="min-w-full text-sm">
        <thead><tr className="text-left">{["Date","Bed","Wake","Lat (min)","Awak","RTS (min)","Sleep (h)","Eff %","Bloat","Energy","Notes",""].map(h=> <th key={h} className="py-2 pr-4 font-medium text-muted-foreground">{h}</th>)}</tr></thead>
        <tbody>
          {entries.length===0 && <tr><td className="py-3" colSpan={12}>No entries yet.</td></tr>}
          {entries.map(e=> (
            <tr key={e.id} className="border-t">
              <td className="py-2 pr-4">{e.date}</td>
              <td className="py-2 pr-4">{e.bedtime}</td>
              <td className="py-2 pr-4">{e.waketime}</td>
              <td className="py-2 pr-4">{e.sleepLatencyMin ?? ""}</td>
              <td className="py-2 pr-4">{e.awakenings ?? ""}</td>
              <td className="py-2 pr-4">{e.returnToSleepMin ?? ""}</td>
              <td className="py-2 pr-4">{e.totalSleepHours ?? ""}</td>
              <td className="py-2 pr-4">{e.sleepEfficiencyPct ?? ""}</td>
              <td className="py-2 pr-4">{e.bloatScore ?? ""}</td>
              <td className="py-2 pr-4">{e.energyScore ?? ""}</td>
              <td className="py-2 pr-4 max-w-[280px] truncate" title={e.notes}>{e.notes}</td>
              <td className="py-2 pr-2 text-right no-print"><Button onClick={()=> onDelete(e.id)} className="btn-outline"><Trash2 className="h-4 w-4"/></Button></td>
            </tr>
          ))}
        </tbody>
      </table>
    </CardContent>
  </Card>
);

function computeTrends(entries: MetricEntry[]) {
  const sorted = [...entries].sort((a,b)=> (a.date < b.date ? -1 : 1));
  const last14 = sorted.slice(-14);
  const last7 = last14.slice(-7);
  const prev7 = last14.slice(-14, -7);
  const avg = (arr:(number|undefined)[]) => { const nums = arr.filter((x): x is number => typeof x === 'number' && !isNaN(x)); if(nums.length===0) return undefined; return nums.reduce((a,b)=> a+b, 0) / nums.length; };
  const r1 = (n?:number) => (n==null? undefined : Math.round(n*10)/10);
  const metrics = (set:MetricEntry[]) => ({ latency: avg(set.map(e=> e.sleepLatencyMin)), awaken: avg(set.map(e=> e.awakenings)), hours: avg(set.map(e=> e.totalSleepHours)), eff: avg(set.map(e=> e.sleepEfficiencyPct)) });
  const k7 = metrics(last7), kPrev = metrics(prev7);
  const delta = (now?:number, then?:number) => { if(now==null||then==null) return undefined; const diff = now-then; const pct = then===0? undefined : (diff/then)*100; return { diff: r1(diff), pct: pct==null? undefined : Math.round(pct) }; };
  const dEff = delta(k7.eff, kPrev.eff), dLat = delta(k7.latency, kPrev.latency), dAwk = delta(k7.awaken, kPrev.awaken), dHrs = delta(k7.hours, kPrev.hours);
  const mkLine = (label:string, d?:{diff?:number,pct?:number}, goodDown=false) => {
    if(!d || d.diff==null) return `${label}: not enough data yet.`;
    const arrow = (goodDown? -1:1) * (d.diff) > 0 ? '↑' : d.diff < 0 ? '↓' : '→';
    const sign = d.diff>0? '+' : '';
    const tail = d.pct==null? '' : ` (${d.pct>0?'+':''}${d.pct}%)`;
    const hint = label==='Sleep Efficiency' ? (d.diff>0? 'Nice improvement.' : d.diff<0? 'Slight dip—recheck evening routine.' : 'Holding steady.') :
                 (label==='Sleep Latency' || label==='Awakenings') ? ((goodDown && d.diff<0)? 'Improved.' : (goodDown && d.diff>0)? 'Worsened—mind caffeine/late meals.' : 'No change.') :
                 (label==='Total Sleep Hours') ? (d.diff>0? 'More total sleep.' : d.diff<0? 'Less total sleep—earlier wind‑down.' : 'Stable.') : '';
    return `${label}: ${arrow} ${sign}${Math.abs(d.diff)}${label==='Total Sleep Hours' ? ' h' : label==='Sleep Latency' || label==='Awakenings' ? ' min' : '%'}${tail} ${hint}`;
  };
  return { lines: [ mkLine('Sleep Efficiency', dEff), mkLine('Sleep Latency', dLat, true), mkLine('Awakenings', dAwk, true), mkLine('Total Sleep Hours', dHrs) ], window: last14 };
}

function formatHM(val?:number){ if(val==null||isNaN(val)) return "—"; return `${Math.round(val*10)/10}`; }
const Sparkline: React.FC<{values:number[]}> = ({values}) => {
  const w=160, h=40, pad=4; if(values.length===0) return <svg width={w} height={h}/>;
  const min=Math.min(...values), max=Math.max(...values);
  const sx=(i:number)=> pad + (i*(w-2*pad))/Math.max(1, values.length-1);
  const sy=(v:number)=> (max===min? h/2 : (h - pad - ((v-min)*(h-2*pad))/(max-min)));
  const pts = values.map((v,i)=> `${sx(i)},${sy(v)}`).join(" ");
  const last = values[values.length-1];
  return <svg width={w} height={h} className="overflow-visible"><polyline points={pts} fill="none" stroke="currentColor" strokeWidth={2} /><circle cx={sx(values.length-1)} cy={sy(last)} r={3} /></svg>;
};

const WeeklySummary: React.FC<{ entries: MetricEntry[] }> = ({entries}) => {
  const byDateDesc = [...entries].sort((a,b)=> (a.date < b.date ? 1 : -1));
  const lastN = (n:number)=> byDateDesc.slice(0,n);
  const avg = (a:(number|undefined)[]) => { const n=a.filter((x):x is number=> typeof x==='number' && !isNaN(x)); if(!n.length) return undefined; return Math.round((n.reduce((p,c)=>p+c,0)/n.length)*10)/10; };
  const vals14 = lastN(14), vals7 = lastN(7);
  const kpi = (set:MetricEntry[]) => ({ latency: avg(set.map(e=> e.sleepLatencyMin)), awak: avg(set.map(e=> e.awakenings)), hours: avg(set.map(e=> e.totalSleepHours)), eff: avg(set.map(e=> e.sleepEfficiencyPct)) });
  const k7=kpi(vals7), k14=kpi(vals14);
  const effSeries = vals14.map(e=> e.sleepEfficiencyPct ?? 0);
  const trends = computeTrends(entries);
  return (
    <Card className="print:break-inside-avoid">
      <CardHeader className="pb-2 flex items-center justify-between">
        <CardTitle className="text-base">Weekly Summary</CardTitle>
        <div className={`text-xs px-2 py-1 rounded ${BRAND.accentClass} text-white`}>Last 14 days</div>
      </CardHeader>
      <CardContent className="grid md:grid-cols-5 gap-4 items-center">
        <div className="md:col-span-2">
          <div className="text-xs text-muted-foreground mb-1">Sleep Efficiency (%)</div>
          <div className={`${BRAND.primaryClass}`}><Sparkline values={effSeries} /></div>
        </div>
        <div><div className="text-xs text-muted-foreground">Avg Latency</div><div className="text-2xl font-semibold">{formatHM(k7.latency)}<span className="text-sm text-muted-foreground"> min (7d)</span></div><div className="text-xs text-muted-foreground">{formatHM(k14.latency)} min (14d)</div></div>
        <div><div className="text-xs text-muted-foreground">Avg Awakenings</div><div className="text-2xl font-semibold">{formatHM(k7.awak)}<span className="text-sm text-muted-foreground"> (7d)</span></div><div className="text-xs text-muted-foreground">{formatHM(k14.awak)} (14d)</div></div>
        <div><div className="text-xs text-muted-foreground">Avg Sleep Hours</div><div className="text-2xl font-semibold">{formatHM(k7.hours)}<span className="text-sm text-muted-foreground"> h (7d)</span></div><div className="text-xs text-muted-foreground">{formatHM(k14.hours)} h (14d)</div></div>
        <div className="md:col-span-5 text-xs text-muted-foreground">{trends.lines.map((l,i)=> <div key={i}>• {l}</div>)}</div>
      </CardContent>
    </Card>
  );
};

const ExportBar: React.FC<{ entries: MetricEntry[]; onPrint:()=>void }> = ({entries,onPrint}) => {
  const downloadCSV = () => {
    const csv = toCSV(entries);
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a"); link.href = url; link.download = `sleep_metrics_${todayISO()}.csv`; link.click(); URL.revokeObjectURL(url);
  };
  return (
    <div className="flex gap-2">
      <Button onClick={downloadCSV} className="btn-outline flex items-center gap-2 no-print"><Download className="h-4 w-4"/>Export CSV</Button>
      <Button onClick={onPrint} className="btn-outline flex items-center gap-2 no-print"><FileText className="h-4 w-4"/>Generate PDF Handout</Button>
      <Button onClick={onPrint} className="btn-outline flex items-center gap-2 no-print"><Printer className="h-4 w-4"/>Print</Button>
    </div>
  );
};

function formatRangeForPrint(entries: MetricEntry[]): string {
  const today = new Date();
  const end = entries.length ? new Date(entries[entries.length-1].date) : today;
  const start = new Date(end); start.setDate(end.getDate()-13);
  const fmt=(d:Date)=> d.toISOString().slice(0,10);
  return `${fmt(start)} to ${fmt(end)}`;
}

export default function Page(){
  const [data, setData] = useLocalData();
  const [date, setDate] = useState<string>(todayISO());
  const [printMode, setPrintMode] = useState(false);

  const day = useMemo(()=> data.checklists[date] ?? defaultChecklist(date), [data.checklists, date]);
  useEffect(()=>{
    setData(d=> ({ ...d, checklists: { ...d.checklists, [day.date]: d.checklists[day.date] ?? day } }));
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [date]);

  const updateChecklist = (section: keyof DayChecklist, id:string, value:boolean) => {
    setData(d=>{
      const current = d.checklists[date] ?? defaultChecklist(date);
      const arr = (current[section] as ChecklistItem[]).map(it => it.id===id ? { ...it, done: value } : it);
      return { ...d, checklists: { ...d.checklists, [date]: { ...current, [section]: arr } } };
    });
  };
  const resetChecklist = (section: keyof DayChecklist) => {
    setData(d=>{
      const current = d.checklists[date] ?? defaultChecklist(date);
      const arr = (current[section] as ChecklistItem[]).map(it => ({...it, done:false}));
      return { ...d, checklists: { ...d.checklists, [date]: { ...current, [section]: arr } } };
    });
  };

  const saveMetrics = (entry: MetricEntry) => setData(d=> ({ ...d, metrics: [entry, ...d.metrics.filter(e=> e.id!==entry.id)] }));
  const deleteMetric = (id:string) => setData(d=> ({ ...d, metrics: d.metrics.filter(e=> e.id!==id) }));

  const allItems = [...day.morning, ...day.midday, ...day.evening, ...day.airway, ...day.supplements];
  const completion = pct(allItems.filter(i=>i.done).length, allItems.length);

  const handlePrint = () => { setPrintMode(true); setTimeout(()=> { window.print(); setPrintMode(false); }, 50); };
  const trendInfo = computeTrends(data.metrics);
  const rangeText = formatRangeForPrint(trendInfo.window);

  return (
    <div className={`p-4 md:p-6 max-w-6xl mx-auto space-y-4 ${printMode ? 'print-ready' : ''}`}>
      <style>{`@media print{ .no-print{ display:none !important } .print\:break-inside-avoid{ break-inside: avoid } body{ -webkit-print-color-adjust: exact; print-color-adjust: exact } a{ color:inherit } .print-footer{ position:fixed; bottom:0; left:0; right:0; padding:8px 24px; font-size:10px } }`}</style>
      <div className="flex items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <img src={BRAND.logoUrl} alt="logo" className="h-12 w-12 rounded-xl object-cover" />
          <div>
            <h1 className={`text-2xl font-bold ${BRAND.primaryClass}`}>{BRAND.name}</h1>
            <div className="text-xs text-muted-foreground">{BRAND.subtitle} • Patient Sleep Toolkit — T.W.</div>
          </div>
        </div>
        <ExportBar entries={data.metrics} onPrint={handlePrint} />
      </div>

      <Card>
        <CardContent className="pt-6 grid md:grid-cols-4 gap-4 items-end">
          <div className="md:col-span-2"><Label className="label">Select Date</Label><Input type="date" value={date} onChange={e=> setDate(e.target.value)} /></div>
          <div><Label className="label">Default Bedtime</Label><Input type="time" value={data.settings.defaultBedtime} onChange={e=> setData(d=> ({...d, settings: { ...d.settings, defaultBedtime: e.target.value }}))} /></div>
          <div><Label className="label">Default Wake Time</Label><Input type="time" value={data.settings.defaultWaketime} onChange={e=> setData(d=> ({...d, settings: { ...d.settings, defaultWaketime: e.target.value }}))} /></div>
          <div className="md:col-span-4 flex items-center justify-between border rounded-lg p-3">
            <div><div className="text-sm font-medium">Daily Completion</div><div className="text-xs text-muted-foreground">{completion}% of checklist items completed</div></div>
            <Progress value={completion} className="w-64" />
          </div>
        </CardContent>
      </Card>

      <WeeklySummary entries={data.metrics} />

      <Tabs defaultValue="checklists">
        <TabsList>
          <TabsTrigger value="checklists">Checklists</TabsTrigger>
          <TabsTrigger value="metrics">Tracker</TabsTrigger>
          <TabsTrigger value="tips">Tips</TabsTrigger>
        </TabsList>

        <TabsContent value="checklists" className="pt-4">
          <div className="grid lg:grid-cols-2 gap-4">
            <ChecklistBlock title="Morning Anchors" items={day.morning} onToggle={(id,v)=> updateChecklist("morning", id, v)} onReset={()=> resetChecklist("morning")} />
            <ChecklistBlock title="Mid‑Day Habits" items={day.midday} onToggle={(id,v)=> updateChecklist("midday", id, v)} onReset={()=> resetChecklist("midday")} />
            <ChecklistBlock title="Evening Wind‑Down" items={day.evening} onToggle={(id,v)=> updateChecklist("evening", id, v)} onReset={()=> resetChecklist("evening")} />
            <ChecklistBlock title="Airway • Sinus • Oral" items={day.airway} onToggle={(id,v)=> updateChecklist("airway", id, v)} onReset={()=> resetChecklist("airway")} />
            <ChecklistBlock title="Supplement Ladder (optional)" items={day.supplements} onToggle={(id,v)=> updateChecklist("supplements", id, v)} onReset={()=> resetChecklist("supplements")} />
          </div>
        </TabsContent>

        <TabsContent value="metrics" className="pt-4">
          <MetricsForm onSave={saveMetrics} defaults={{ bedtime: data.settings.defaultBedtime, waketime: data.settings.defaultWaketime }} />
          <EntriesTable entries={data.metrics} onDelete={deleteMetric} />
        </TabsContent>

        <TabsContent value="tips" className="pt-4">
          <Card className="print:break-inside-avoid">
            <CardHeader className="pb-2"><CardTitle className="text-base">Quick Tips</CardTitle></CardHeader>
            <CardContent className="space-y-2 text-sm">
              <p><strong>Keep the wake time fixed</strong> (±30 min) even after rough nights.</p>
              <p>Front‑load calories earlier in the day; finish big meals 3+ hours before bed. If hungry later, use a <em>small protein + starch</em> snack.</p>
              <p>Use nasal saline after work and before bed; run the bedroom HEPA nightly.</p>
              <p>Introduce new supplements one at a time every 3–4 nights; stop if adverse reactions occur.</p>
              <div className="flex items-center gap-2">
                <Switch checked={data.settings.showHistamineTips} onCheckedChange={(v)=> setData(d=> ({...d, settings: { ...d.settings, showHistamineTips: Boolean(v) }}))} />
                <Label className="label">Show low‑histamine PM tips</Label>
              </div>
              {data.settings.showHistamineTips && (
                <ul className="list-disc pl-5 space-y-1">
                  <li>Limit high‑histamine foods at dinner: aged meats/cheeses, wine, canned fish, vinegars.</li>
                  <li>Prefer fresh‑cooked meals; avoid leftovers kept >48 hours.</li>
                </ul>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <div className="print-footer text-muted-foreground">
        <div><strong>{BRAND.name}</strong> — {BRAND.subtitle} • <a href={BRAND.siteUrl} target="_blank" rel="noreferrer">{BRAND.siteUrl}</a></div>
        <div>14‑day handout window: {rangeText}</div>
        {trendInfo.lines.length>0 && (<div>{trendInfo.lines.map((l,i)=> (<span key={i}>{i>0? ' • ' : ''}{l}</span>))}</div>)}
      </div>

      <div className="text-xs text-muted-foreground pt-2">Data is stored locally in your browser (no cloud). This tool is educational and not a substitute for medical care.</div>
    </div>
  );
}