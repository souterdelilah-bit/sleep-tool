'use client';
import * as React from "react";
export function Switch({checked, onCheckedChange}:{checked?:boolean,onCheckedChange?:(v:boolean)=>void}){
  return (
    <button onClick={()=> onCheckedChange && onCheckedChange(!checked)} className={`switch ${checked? 'bg-emerald-600' : 'bg-gray-200'}`}>
      <span className={`switch-thumb ${checked? 'translate-x-5' : 'translate-x-1'}`} />
    </button>
  );
}