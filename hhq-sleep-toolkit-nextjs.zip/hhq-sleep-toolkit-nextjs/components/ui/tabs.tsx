'use client';
import * as React from "react";

const TabsContext = React.createContext<{value:string,setValue:(v:string)=>void}|null>(null);

export function Tabs({ defaultValue, children }: { defaultValue: string, children: React.ReactNode }){
  const [value, setValue] = React.useState(defaultValue);
  return <TabsContext.Provider value={{value,setValue}}><div>{children}</div></TabsContext.Provider>;
}
export function TabsList({ children }: { children: React.ReactNode }){ return <div className="flex gap-2 mt-2">{children}</div>; }
export function TabsTrigger({ value, children }: { value: string, children: React.ReactNode }){
  const ctx = React.useContext(TabsContext)!;
  const active = ctx.value === value;
  return <button onClick={()=> ctx.setValue(value)} className={`tabs-tab ${active? 'tabs-tab-active' : ''}`}>{children}</button>;
}
export function TabsContent({ value, children, className='' }: { value: string, children: React.ReactNode, className?: string }){
  const ctx = React.useContext(TabsContext)!;
  if (ctx.value !== value) return null;
  return <div className={className}>{children}</div>;
}