import * as React from "react";
export function Card(props: React.HTMLAttributes<HTMLDivElement>) {
  return <div {...props} className={`card ${props.className||''}`} />;
}
export function CardHeader(props: React.HTMLAttributes<HTMLDivElement>) {
  return <div {...props} className={`px-5 pt-5 ${props.className||''}`} />;
}
export function CardContent(props: React.HTMLAttributes<HTMLDivElement>) {
  return <div {...props} className={`px-5 pb-5 ${props.className||''}`} />;
}
export function CardTitle(props: React.HTMLAttributes<HTMLDivElement>) {
  return <div {...props} className={`text-xl font-semibold ${props.className||''}`} />;
}