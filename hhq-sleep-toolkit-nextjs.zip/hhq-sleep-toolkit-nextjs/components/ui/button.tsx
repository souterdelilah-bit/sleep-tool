import * as React from "react";
export function Button({ className='', variant='outline', ...props }: React.ButtonHTMLAttributes<HTMLButtonElement> & {variant?: 'outline'|'solid'}) {
  return <button className={`btn ${variant==='solid' ? 'btn-solid' : 'btn-outline'} ${className}`} {...props} />;
}