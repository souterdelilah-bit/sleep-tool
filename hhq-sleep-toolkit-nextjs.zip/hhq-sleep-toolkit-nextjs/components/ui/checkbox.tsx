import * as React from "react";
export function Checkbox({checked, onCheckedChange}: {checked?: boolean, onCheckedChange?: (v:boolean)=>void}) {
  return (
    <input type="checkbox" className="h-4 w-4 rounded border-gray-300" checked={!!checked} onChange={e=> onCheckedChange && onCheckedChange(e.target.checked)} />
  );
}